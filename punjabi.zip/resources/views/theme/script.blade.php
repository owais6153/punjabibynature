<script src="{!! asset('storage/app/public/assets/plugins/common/common.min.js') !!}"></script>

<script src="{!! asset('storage/app/public/assets/js/custom.min.js') !!}"></script>

<script src="{!! asset('storage/app/public/assets/js/settings.js') !!}"></script>

<script src="{!! asset('storage/app/public/assets/js/gleek.js') !!}"></script>

<script src="{!! asset('storage/app/public/assets/js/styleSwitcher.js') !!}"></script>



<!-- Circle progress -->

<script src="{!! asset('storage/app/public/assets/plugins/circle-progress/circle-progress.min.js') !!}"></script>

<!-- Datamap -->

<script src="{!! asset('storage/app/public/assets/plugins/d3v3/index.js') !!}"></script>

<script src="{!! asset('storage/app/public/assets/plugins/topojson/topojson.min.js') !!}"></script>

<!-- Morrisjs -->

<script src="{!! asset('storage/app/public/assets/plugins/raphael/raphael.min.js') !!}"></script>

<script src="{!! asset('storage/app/public/assets/plugins/morris/morris.min.js') !!}"></script>

<!-- Pignose Calender -->

<script src="{!! asset('storage/app/public/assets/plugins/moment/moment.min.js') !!}"></script>

<script src="{!! asset('storage/app/public/assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js') !!}"></script>
<!-- Clock Plugin JavaScript -->
<script src="{!! asset('storage/app/public/assets/plugins/clockpicker/dist/jquery-clockpicker.min.js') !!}"></script>
<!-- Color Picker Plugin JavaScript -->
<script src="{!! asset('storage/app/public/assets/plugins/jquery-asColorPicker-master/libs/jquery-asColor.js') !!}"></script>
<script src="{!! asset('storage/app/public/assets/plugins/jquery-asColorPicker-master/libs/jquery-asGradient.js') !!}"></script>
<script src="{!! asset('storage/app/public/assets/plugins/jquery-asColorPicker-master/dist/jquery-asColorPicker.min.js') !!}"></script>
<!-- Date Picker Plugin JavaScript -->
<script src="{!! asset('storage/app/public/assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js') !!}"></script>
<!-- Date range Plugin JavaScript -->
<script src="{!! asset('storage/app/public/assets/plugins/timepicker/bootstrap-timepicker.min.js') !!}"></script>
<script src="{!! asset('storage/app/public/assets/plugins/bootstrap-daterangepicker/daterangepicker.js') !!}"></script>
<script src="{!! asset('storage/app/public/assets/js/plugins-init/form-pickers-init.js') !!}"></script>

<script src="{!! asset('storage/app/public/assets/plugins/pg-calendar/js/pignose.calendar.min.js') !!}"></script>


<script src="{!! asset('storage/app/public/assets/plugins/sweetalert/js/sweetalert.min.js') !!}"></script>



<script src="{!! asset('storage/app/public/assets/plugins/tables/js/jquery.dataTables.min.js') !!}"></script>

<script src="{!! asset('storage/app/public/assets/plugins/tables/js/datatable/dataTables.bootstrap4.min.js') !!}"></script>

<script src="{!! asset('storage/app/public/assets/plugins/tables/js/datatable-init/datatable-basic.min.js') !!}"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-Z47HEB289L"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-Z47HEB289L');
</script>
@yield('script')