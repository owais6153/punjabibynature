<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>#</th>
            <th><?php echo e(trans('labels.offer_name')); ?></th>
            <th><?php echo e(trans('labels.offer_code')); ?></th>
            <th><?php echo e(trans('labels.offer_percentage')); ?></th>
            <th><?php echo e(trans('labels.offer_description')); ?> </th>
            <th><?php echo e(trans('labels.created_at')); ?></th>
            <th><?php echo e(trans('labels.action')); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($getpromocode as $promocode) {
        ?>
        <tr id="dataid<?php echo e($promocode->id); ?>">
            <td><?php echo e($promocode->id); ?></td>
            <td><?php echo e($promocode->offer_name); ?></td>
            <td><?php echo e($promocode->offer_code); ?></td>
            <td><?php echo e($promocode->offer_amount); ?></td>
            <td><?php echo e($promocode->description); ?></td>
            <td><?php echo e($promocode->created_at); ?></td>
            <td>
                <span>
                    <a href="#" data-toggle="tooltip" data-placement="top" onclick="GetData('<?php echo e($promocode->id); ?>')" title="" data-original-title="<?php echo e(trans('labels.edit')); ?>">
                        <span class="badge badge-success"><?php echo e(trans('labels.edit')); ?></span>
                    </a>
                    <?php if(env('Environment') == 'sendbox'): ?>
                        <a href="#" data-toggle="tooltip" data-placement="top" onclick="myFunction()" title="" data-original-title="<?php echo e(trans('labels.delete')); ?>">
                            <span class="badge badge-danger"><?php echo e(trans('labels.delete')); ?></span>
                        </a>
                    <?php else: ?>
                        <a class="badge badge-danger px-2" onclick="StatusUpdate('<?php echo e($promocode->id); ?>','2')" style="color: #fff;"><?php echo e(trans('labels.delete')); ?></a>
                    <?php endif; ?>
                </span>
            </td>
        </tr>
        <?php
        }
        ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/theme/promocodetable.blade.php ENDPATH**/ ?>