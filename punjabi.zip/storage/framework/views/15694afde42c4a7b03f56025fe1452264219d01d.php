<?php echo $__env->make('front.theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="favourite">
    <div class="container">
        <h2 class="sec-head"><?php echo e(trans('labels.terms_conditions')); ?></h2>
        <div class="row">
            <?php echo $gettermscondition->termscondition_content; ?>

        </div>
    </div>
</section>

<?php echo $__env->make('front.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/front/terms.blade.php ENDPATH**/ ?>