<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>#</th>
            <th><?php echo e(trans('labels.pincode')); ?></th>
            <th><?php echo e(trans('labels.delivery_charge')); ?></th>
            <th><?php echo e(trans('labels.created_at')); ?></th>
            <th><?php echo e(trans('labels.action')); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($getpincode as $pincode) {
        ?>
        <tr id="dataid<?php echo e($pincode->id); ?>">
            <td><?php echo e($pincode->id); ?></td>
            <td><?php echo e($pincode->pincode); ?></td>
            <td><?php echo e(Auth::user()->currency); ?><?php echo e($pincode->delivery_charge); ?></td>
            <td><?php echo e($pincode->created_at); ?></td>
            <td>
                <span>
                    <a href="#" data-toggle="tooltip" data-placement="top" onclick="GetData('<?php echo e($pincode->id); ?>')" title="" data-original-title="<?php echo e(trans('labels.edit')); ?>">
                        <span class="badge badge-success"><?php echo e(trans('labels.edit')); ?></span>
                    </a>
                    <?php if(env('Environment') == 'sendbox'): ?>
                        <a href="#" data-toggle="tooltip" data-placement="top" onclick="myFunction()" title="" data-original-title="<?php echo e(trans('labels.delete')); ?>">
                            <span class="badge badge-danger"><?php echo e(trans('labels.delete')); ?></span>
                        </a>
                    <?php else: ?>
                        <a class="badge badge-danger px-2" onclick="DeleteData('<?php echo e($pincode->id); ?>','2')" style="color: #fff;"><?php echo e(trans('labels.delete')); ?></a>
                    <?php endif; ?>
                </span>
            </td>
        </tr>
        <?php
        }
        ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/theme/pincodetable.blade.php ENDPATH**/ ?>