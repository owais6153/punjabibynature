<?php $__env->startSection('content'); ?>
<style type="text/css">
    .pac-container {
    z-index: 10000 !important;
}
</style>
<div class="row page-titles mx-0">
    <div class="col p-md-0">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/admin/home')); ?>"><?php echo e(trans('labels.dashboard')); ?></a></li>
            <li class="breadcrumb-item active"><a href="javascript:void(0)"><?php echo e(trans('labels.items')); ?></a></li>
        </ol>
        <a href="<?php echo e(URL::to('/admin/additem')); ?>" class="btn btn-primary" ><?php echo e(trans('labels.add_item')); ?></a>

    </div>
</div>
<!-- row -->

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <span id="message"></span>
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title"><?php echo e(trans('labels.all_items')); ?></h4>
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                        <?php
                            Session::forget('success');
                        ?>
                    </div>
                    <?php endif; ?>
                    <div class="table-responsive" id="table-display">
                        <?php echo $__env->make('theme.itemtable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- #/ container -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $('.table').dataTable({
      aaSorting: [[0, 'DESC']]
    });
function StatusUpdate(id,status) {
    swal({
        title: "<?php echo e(trans('messages.are_you_sure')); ?>",
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: "<?php echo e(trans('messages.yes')); ?>",
        cancelButtonText: "<?php echo e(trans('messages.no')); ?>",
        closeOnConfirm: false,
        closeOnCancel: false,
        showLoaderOnConfirm: true,
    },
    function(isConfirm) {
        if (isConfirm) {
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url:"<?php echo e(URL::to('admin/item/status')); ?>",
                data: {
                    id: id,
                    status: status
                },
                method: 'POST', //Post method,
                dataType: 'json',
                success: function(response) {
                    if (response == 1) {
                        swal.close();
                        ProductTable();
                    } else {
                        swal("Cancelled", "<?php echo e(trans('messages.wrong')); ?> :(", "error");
                    }
                },
                error: function(e) {
                    swal("Cancelled", "<?php echo e(trans('messages.wrong')); ?> :(", "error");
                }
            });
        } else {
            swal("Cancelled", "<?php echo e(trans('messages.record_safe')); ?> :)", "error");
        }
    });
}

function Delete(id) {
    swal({
        title: "<?php echo e(trans('messages.are_you_sure')); ?>",
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: "<?php echo e(trans('messages.yes')); ?>",
        cancelButtonText: "<?php echo e(trans('messages.no')); ?>",
        closeOnConfirm: false,
        closeOnCancel: false,
        showLoaderOnConfirm: true,
    },
    function(isConfirm) {
        if (isConfirm) {
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url:"<?php echo e(URL::to('admin/item/delete')); ?>",
                data: {
                    id: id
                },
                method: 'POST', //Post method,
                dataType: 'json',
                success: function(response) {
                    if (response == 1) {
                        swal.close();
                        ProductTable();
                    } else {
                        swal("Cancelled", "<?php echo e(trans('messages.wrong')); ?> :(", "error");
                    }
                },
                error: function(e) {
                    swal("Cancelled", "<?php echo e(trans('messages.wrong')); ?> :(", "error");
                }
            });
        } else {
            swal("Cancelled", "<?php echo e(trans('messages.record_safe')); ?> :)", "error");
        }
    });
}
function ProductTable() {
    $('#preloader').show();
    $.ajax({
        url:"<?php echo e(URL::to('admin/item/list')); ?>",
        method:'get',
        success:function(data){
            $('#preloader').hide();
            $('#table-display').html(data);
            $(".zero-configuration").DataTable({
              aaSorting: [[0, 'DESC']]
            })
        }
    });
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/item.blade.php ENDPATH**/ ?>