<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>#</th>
            <th>Image</th>
            <th>Ingredient</th>
            <th>Created at</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($getingredients as $ingredients) {
        ?>
        <tr id="dataid<?php echo e($ingredients->id); ?>">
            <td><?php echo e($ingredients->id); ?></td>
            <td><img src='<?php echo asset("storage/app/public/images/ingredients/".$ingredients->image); ?>' class='img-fluid' style='max-height: 50px;'></td>
            <td><?php echo e($ingredients->ingredients); ?></td>
            <td><?php echo e($ingredients->created_at); ?></td>
            <?php if(env('Environment') == 'sendbox'): ?>
                <td>
                    <span>
                        <a href="#" data-toggle="tooltip" data-placement="top" onclick="GetData('<?php echo e($ingredients->id); ?>')" title="" data-original-title="Edit">
                            <span class="badge badge-success">Edit</span>
                        </a>

                        <a class="badge badge-danger px-2" onclick="myFunction()" style="color: #fff;">Delete</a>
                    </span>
                </td>
            <?php else: ?>
                <td>
                    <span>
                        <a href="#" data-toggle="tooltip" data-placement="top" onclick="GetData('<?php echo e($ingredients->id); ?>')" title="" data-original-title="Edit">
                            <span class="badge badge-success">Edit</span>
                        </a>

                        <a class="badge badge-danger px-2" onclick="Delete('<?php echo e($ingredients->id); ?>')" style="color: #fff;">Delete</a>
                    </span>
                </td>
            <?php endif; ?>
        </tr>
        <?php
        }
        ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/theme/ingredientstable.blade.php ENDPATH**/ ?>