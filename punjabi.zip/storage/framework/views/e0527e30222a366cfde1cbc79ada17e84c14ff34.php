<?php echo $__env->make('front.theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>>
<style>
    .pac-container {
        z-index: 10000 !important;
    }
    .error {
        color: red;
    }
</style>
<section class="favourite">
    <div class="container">
        <h2 class="sec-head"><?php echo e(trans('labels.my_address')); ?></h2>

        <?php if(\Session::has('success')): ?>
            <div class="alert alert-success" style="text-align: center;">
                <?php echo \Session::get('success'); ?>

            </div>
        <?php endif; ?>

        <?php if(\Session::has('danger')): ?>
            <div class="alert alert-danger" style="text-align: center;">
                <?php echo \Session::get('danger'); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->address->first('address')): ?>

            <div class="alert alert-danger" style="text-align: center;">

                <?php echo e($errors->address->first('address')); ?>


            </div>

        <?php endif; ?>

        <button type="button" class="btn" data-toggle="modal" data-target="#addAddress" data-whatever="@addAddress"><?php echo e(trans('labels.add_address')); ?></button>

        <div class="row">
            <?php if(count($addressdata) == 0): ?>
                <p><?php echo e(trans('labels.no_data')); ?></p>
            <?php else: ?> 
                <?php $__currentLoopData = $addressdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 mt-5">
                    <div class="order-box">
                        <div class="order-box-no">
                            <?php if($address->address_type == 1): ?>
                                <?php echo e(trans('labels.home')); ?>

                            <?php elseif($address->address_type == 2): ?>
                                <?php echo e(trans('labels.work')); ?>

                            <?php elseif($address->address_type == 3): ?>
                                <?php echo e(trans('labels.other')); ?>

                            <?php endif; ?>
                            <h4><?php echo e($address->address); ?></h4>
                            <span class="order-status"><?php echo e(trans('labels.landmark')); ?> : <span><?php echo e($address->landmark); ?></span></span><br>
                            <span class="order-status"><?php echo e(trans('labels.door_no')); ?> : <span><?php echo e($address->building); ?></span></span><br>
                            <span class="order-status"><?php echo e(trans('labels.pincode')); ?> : <span><?php echo e($address->pincode); ?></span></span>
                        </div>
                        <div class="order-box-price">
                            <h6><a href="#" onclick="GetData('<?php echo e($address->id); ?>')"> <?php echo e(trans('labels.edit')); ?> </a></h6>
                            <h6><a href="#" onclick="DeleteAddress('<?php echo e($address->id); ?>','<?php echo e(Session::get('id')); ?>')"> <?php echo e(trans('labels.delete')); ?> </a></h6>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <?php echo $addressdata->links(); ?>

    </div>
</section>

<!-- Add Address -->
<div class="modal fade" id="addAddress" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(trans('labels.add_address')); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            <form id="add_address" method="post" action="<?php echo e(URL::to('/user/addaddress')); ?>">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php if(env('Environment') == 'sendbox'): ?>
                    <span style="color: red;" id="dummy-msg">You can not change this address in Demo version. When you'll purchase. it will work properly.</span>
                    <br>
                        <label><?php echo e(trans('labels.address_type')); ?></label>
                        <div class="form-group">
                            <select class="form-control" name="address_type" id="address_type" >
                                <option value=""><?php echo e(trans('messages.select_address_type')); ?></option>
                                <option value="1"><?php echo e(trans('labels.home')); ?></option>
                                <option value="2"><?php echo e(trans('labels.work')); ?></option>
                                <option value="3"><?php echo e(trans('labels.other')); ?></option>
                            </select>
                        </div>
                        <label><?php echo e(trans('labels.address')); ?></label>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="<?php echo e(trans('messages.enter_delivery_address')); ?>" name="address" id="address" value="New York, NY, USA" required="" readonly="" autocomplete="on" >
                            <input type="hidden" id="lat" name="lat" value="40.7127753" />
                            <input type="hidden" id="lang" name="lang" value="-74.0059728" />
                            <input type="hidden" id="city" name="city" placeholder="city" value="New York" /> 
                            <input type="hidden" id="state" name="state" placeholder="state" value="NY" /> 
                            <input type="hidden" id="country" name="country" placeholder="country" value="US" />
                        </div>
                        <label><?php echo e(trans('labels.landmark')); ?></label>
                        <div class="form-group">
                            <input type="text" class="form-control" name="landmark" id="landmark" placeholder="<?php echo e(trans('messages.enter_landmark')); ?>" value="Central Park" readonly="">
                        </div>
                        <label><?php echo e(trans('labels.building')); ?></label>
                        <div class="form-group">
                            <input type="text" class="form-control" name="building" id="building" placeholder="<?php echo e(trans('messages.enter_building')); ?>" value="4043" readonly="">
                        </div>
                        <label><?php echo e(trans('labels.pincode')); ?></label>
                        <div class="form-group">
                            <select class="form-control" name="pincode" id="pincode">
                                <option value=""><?php echo e(trans('messages.select_pincode')); ?></option>
                                <?php $__currentLoopData = $getpincode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pincode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pincode->pincode); ?>"><?php echo e($pincode->pincode); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php else: ?>
                        <label><?php echo e(trans('labels.address_type')); ?></label>
                        <div class="form-group">
                            <select class="form-control" name="address_type" id="address_type">
                                <option value=""><?php echo e(trans('messages.select_address_type')); ?></option>
                                <option value="1"><?php echo e(trans('labels.home')); ?></option>
                                <option value="2"><?php echo e(trans('labels.work')); ?></option>
                                <option value="3"><?php echo e(trans('labels.other')); ?></option>
                            </select>
                        </div>
                        <label><?php echo e(trans('labels.address')); ?></label>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="<?php echo e(trans('messages.enter_delivery_address')); ?>" name="address" id="address" autocomplete="on">
                            <input type="hidden" id="lat" name="lat" />
                            <input type="hidden" id="lang" name="lang" />
                            <input type="hidden" id="city" name="city" /> 
                            <input type="hidden" id="state" name="state" /> 
                            <input type="hidden" id="country" name="country" />
                        </div>
                        <label><?php echo e(trans('labels.landmark')); ?></label>
                        <div class="form-group">
                            <input type="text" class="form-control" name="landmark" id="landmark" placeholder="<?php echo e(trans('messages.enter_landmark')); ?>">
                        </div>
                        <label><?php echo e(trans('labels.building')); ?></label>
                        <div class="form-group">
                            <input type="text" class="form-control" name="building" id="building" placeholder="<?php echo e(trans('messages.enter_building')); ?>">
                        </div>
                        <label><?php echo e(trans('labels.pincode')); ?></label>
                        <div class="form-group">
                            <select class="form-control" name="pincode" id="pincode">
                                <option value=""><?php echo e(trans('messages.select_pincode')); ?></option>
                                <?php $__currentLoopData = $getpincode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pincode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pincode->pincode); ?>"><?php echo e($pincode->pincode); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(trans('labels.close')); ?></button>
                    <button type="submit" class="btn btn-primary"><?php echo e(trans('labels.save')); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Edit Address -->
<div class="modal fade" id="EditAddress" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelEdit" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabelEdit"><?php echo e(trans('labels.address')); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            <form id="edit_address" method="post" action="<?php echo e(URL::to('/user/editaddress')); ?>">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" class="form-control" name="id" id="id">
                    <label><?php echo e(trans('labels.address_type')); ?></label>
                    <div class="form-group">
                        <select class="form-control" name="address_type" id="get_address_type">
                            <option value=""><?php echo e(trans('messages.select_address_type')); ?></option>
                            <option value="1"><?php echo e(trans('labels.home')); ?></option>
                            <option value="2"><?php echo e(trans('labels.work')); ?></option>
                            <option value="3"><?php echo e(trans('labels.other')); ?></option>
                        </select>
                    </div>
                    <label><?php echo e(trans('labels.address')); ?></label>
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="<?php echo e(trans('messages.enter_delivery_address')); ?>" name="address" id="get_address" autocomplete="on">
                        <input type="hidden" id="get_lat" name="lat" />
                        <input type="hidden" id="get_lang" name="lang" />
                        <input type="hidden" id="get_city" name="city" /> 
                        <input type="hidden" id="get_state" name="state" /> 
                        <input type="hidden" id="get_country" name="country" />
                    </div>
                    <label><?php echo e(trans('labels.landmark')); ?></label>
                    <div class="form-group">
                        <input type="text" class="form-control" name="landmark" id="get_landmark" placeholder="<?php echo e(trans('messages.enter_landmark')); ?>">
                    </div>
                    <label><?php echo e(trans('labels.building')); ?></label>
                    <div class="form-group">
                        <input type="text" class="form-control" name="building" id="get_building" placeholder="<?php echo e(trans('messages.enter_building')); ?>">
                    </div>
                    <label><?php echo e(trans('labels.pincode')); ?></label>
                    <div class="form-group">
                        <select class="form-control" name="pincode" id="get_pincode">
                            <option value=""><?php echo e(trans('messages.select_pincode')); ?></option>
                            <?php $__currentLoopData = $getpincode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pincode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pincode->pincode); ?>"><?php echo e($pincode->pincode); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(trans('labels.close')); ?></button>
                    <button type="submit" class="btn btn-primary"><?php echo e(trans('labels.update')); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php echo $__env->make('front.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=<?php echo e($getdata->map); ?>&libraries=places"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script>
    $(document).ready(function() {
        "use strict";
        $( "#add_address" ).validate({
            rules :{
                address_type: {
                    required: true,
                }, 
                address: {
                    required: true,
                }, 
                landmark: {
                    required: true,
                }, 
                building: {
                    required: true,
                }, 
                pincode: {
                    required: true,
                },                    
            },

        });    

        $( "#edit_address" ).validate({
            rules :{
                address_type: {
                    required: true,
                }, 
                address: {
                    required: true,
                }, 
                landmark: {
                    required: true,
                }, 
                building: {
                    required: true,
                }, 
                pincode: {
                    required: true,
                },                    
            },

        });      
    });
</script>

<?php if(env('Environment') != 'sendbox'): ?>
<script>
    function initialize() {
        "use strict";
      var input = document.getElementById('address');
      var autocomplete = new google.maps.places.Autocomplete(input);
        google.maps.event.addListener(autocomplete, 'place_changed', function () {
            var place = autocomplete.getPlace();

            for (var i = 0; i < place.address_components.length; i++) {
                var addressType = place.address_components[i].types[0];
                
                if (addressType == "administrative_area_level_1") {
                  document.getElementById("state").value = place.address_components[i].short_name;
                }

                if (addressType == "locality") {
                  document.getElementById("city").value = place.address_components[i].short_name;
                }

                // for the country, get the country code (the "short name") also
                if (addressType == "country") {
                  document.getElementById("country").value = place.address_components[i].short_name;
                }
              }

            document.getElementById('lat').value = place.geometry.location.lat();
            document.getElementById('lang').value = place.geometry.location.lng();
        });
    }
    google.maps.event.addDomListener(window, 'load', initialize);

    function addinitialize() {
        "use strict";
      var input = document.getElementById('get_address');
      var autocomplete = new google.maps.places.Autocomplete(input);
        google.maps.event.addListener(autocomplete, 'place_changed', function () {
            var place = autocomplete.getPlace();

            for (var i = 0; i < place.address_components.length; i++) {
                var addressType = place.address_components[i].types[0];
                
                if (addressType == "administrative_area_level_1") {
                  document.getElementById("get_state").value = place.address_components[i].short_name;
                }

                if (addressType == "locality") {
                  document.getElementById("get_city").value = place.address_components[i].short_name;
                }

                // for the country, get the country code (the "short name") also
                if (addressType == "country") {
                  document.getElementById("get_country").value = place.address_components[i].short_name;
                }
              }

            document.getElementById('get_lat').value = place.geometry.location.lat();
            document.getElementById('get_lang').value = place.geometry.location.lng();
        });
    }
    google.maps.event.addDomListener(window, 'load', addinitialize);
</script>
<?php endif; ?>

<script type="text/javascript">
    function GetData(id) {
        "use strict";
        $('#preloader').show();
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url:"<?php echo e(URL::to('/user/show')); ?>",
            data: {
                id: id
            },
            method: 'POST', //Post method,
            dataType: 'json',
            success: function(response) {
                $('#preloader').hide();
                jQuery("#EditAddress").modal('show');
                $('#id').val(response.ResponseData.id);
                $('#get_address_type').val(response.ResponseData.address_type);
                $('#get_address').val(response.ResponseData.address);
                $('#get_lat').val(response.ResponseData.lat);
                $('#get_lang').val(response.ResponseData.lang);
                $('#get_city').val(response.ResponseData.city);
                $('#get_country').val(response.ResponseData.country);
                $('#get_state').val(response.ResponseData.state);
                $('#get_landmark').val(response.ResponseData.landmark);
                $('#get_building').val(response.ResponseData.building);
                $('#get_pincode').val(response.ResponseData.pincode);
            },
            error: function(error) {
                $('#preloader').hide();
            }
        })
    }
    function DeleteAddress(id,user_id) {
        "use strict";
        swal({
            title: "<?php echo e(trans('messages.are_you_sure')); ?>",
            type: 'error',
            showCancelButton: true,
            confirmButtonText: "<?php echo e(trans('messages.yes')); ?>",
            cancelButtonText: "<?php echo e(trans('messages.no')); ?>"
        },
        function(isConfirm) {
            if (isConfirm) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url:"<?php echo e(URL::to('/user/delete')); ?>",
                    data: {
                        id: id,
                        user_id: user_id
                    },
                    method: 'POST',
                    success: function(response) {
                        if (response == 1) {
                            location.reload();
                        } else {
                            swal("Cancelled", "<?php echo e(trans('messages.wrong')); ?> :(", "error");
                        }
                    },
                    error: function(e) {
                        swal("Cancelled", "<?php echo e(trans('messages.wrong')); ?> :(", "error");
                    }
                });
            } else {
                swal("Cancelled", "<?php echo e(trans('messages.record_safe')); ?> :)", "error");
            }
        });
    };
</script><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/front/address.blade.php ENDPATH**/ ?>