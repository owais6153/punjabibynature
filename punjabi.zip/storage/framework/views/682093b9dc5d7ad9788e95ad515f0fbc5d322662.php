<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>#</th>
            <th><?php echo e(trans('labels.username')); ?></th>
            <th><?php echo e(trans('labels.order_number')); ?></th>
            <th><?php echo e(trans('labels.payment_type')); ?></th>
            <th><?php echo e(trans('labels.payment_id')); ?></th>
            <th><?php echo e(trans('labels.order_type')); ?></th>
            <th><?php echo e(trans('labels.order_status')); ?></th>
            <th><?php echo e(trans('labels.order_assigned_to')); ?></th>
            <th><?php echo e(trans('labels.created_at')); ?></th>
            <th><?php echo e(trans('labels.change_status')); ?></th>
            <th><?php echo e(trans('labels.action')); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php
        $i = 1;
        foreach ($todayorders as $orders) {
        ?>
        <tr id="dataid<?php echo e($orders->id); ?>">
            <td><?php echo e($i); ?></td>
            <td><?php echo e($orders['users']->name); ?></td>
            <td><?php echo e($orders->order_number); ?></td>
            <td>
                <?php if($orders->payment_type == 1): ?>
                    <?php echo e(trans('labels.razorpay_payment')); ?>

                <?php elseif($orders->payment_type == 2): ?>
                    <?php echo e(trans('labels.stripe_payment')); ?>

                <?php elseif($orders->payment_type == 3): ?>
                    <?php echo e(trans('labels.wallet_payment')); ?>

                <?php else: ?>
                    <?php echo e(trans('labels.cash_payment')); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php if($orders->razorpay_payment_id == ''): ?>
                    --
                <?php else: ?>
                    <?php echo e($orders->razorpay_payment_id); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php if($orders->order_type == 1): ?>
                    <?php echo e(trans('labels.delivery')); ?>

                <?php else: ?>
                    <?php echo e(trans('labels.pickup')); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php if($orders->status == '1'): ?>
                    <?php echo e(trans('labels.order_received')); ?>

                <?php elseif($orders->status == '2'): ?>
                    <?php echo e(trans('labels.order_on_the_way')); ?>

                <?php elseif($orders->status == '3'): ?>
                    <?php echo e(trans('labels.assigned_to_driver')); ?>

                <?php elseif($orders->status == '4'): ?>
                    <?php echo e(trans('labels.delivered')); ?>

                <?php else: ?>
                    <?php echo e(trans('labels.cancelled')); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php if($orders->name == ""): ?>
                    --
                <?php else: ?>
                    <?php echo e($orders->name); ?>

                <?php endif; ?>
            </td>
            <td><?php echo e($orders->created_at); ?></td>
            <td>
                <?php if($orders->status == '1'): ?>
                    <a ddata-toggle="tooltip" data-placement="top" onclick="StatusUpdate('<?php echo e($orders->id); ?>','2')" title="" data-original-title="<?php echo e(trans('labels.order_received')); ?>">
                        <span class="badge badge-secondary px-2" style="color: #fff;"><?php echo e(trans('labels.order_received')); ?></span>
                    </a>
                <?php elseif($orders->status == '2'): ?>
                    <?php if($orders->order_type == '2'): ?>
                        <a class="badge badge-primary px-2" onclick="StatusUpdate('<?php echo e($orders->id); ?>','4')" style="color: #fff;"><?php echo e(trans('labels.pickup')); ?></a>
                    <?php else: ?>
                        <a class="open-AddBookDialog badge badge-primary px-2" data-toggle="modal" data-id="<?php echo e($orders->id); ?>" data-target="#myModal" style="color: #fff;"><?php echo e(trans('labels.assign_to_driver')); ?></a>
                    <?php endif; ?>
                <?php elseif($orders->status == '3'): ?>
                    <a ddata-toggle="tooltip" data-placement="top" title="" data-original-title="Out for Delivery">
                        <span class="badge badge-success px-2" onclick="StatusUpdate('<?php echo e($orders->id); ?>','4')" style="color: #fff;"><?php echo e(trans('labels.assigned_to_driver')); ?></span>
                    </a>
                <?php elseif($orders->status == '4'): ?>
                    <a ddata-toggle="tooltip" data-placement="top" title="" data-original-title="Out for Delivery">
                        <span class="badge badge-success px-2" style="color: #fff;"><?php echo e(trans('labels.delivered')); ?></span>
                    </a>
                <?php else: ?>
                    <span class="badge badge-danger px-2"><?php echo e(trans('labels.cancelled')); ?></span>
                <?php endif; ?>

                <?php if($orders->status != '4' && $orders->status != '5' && $orders->status != '6'): ?>
                    <a data-toggle="tooltip" data-placement="top" onclick="StatusUpdate('<?php echo e($orders->id); ?>','6')" title="" data-original-title="<?php echo e(trans('labels.cancel')); ?>">
                        <span class="badge badge-danger px-2" style="color: #fff;"><?php echo e(trans('labels.cancel')); ?></span>
                    </a>
                <?php endif; ?>
            </td>
            <td>
                <span>
                    <a data-toggle="tooltip" href="<?php echo e(URL::to('admin/invoice/'.$orders->id)); ?>" data-original-title="<?php echo e(trans('labels.view')); ?>">
                        <span class="badge badge-warning"><?php echo e(trans('labels.view')); ?></span>
                    </a>
                </span>
            </td>
        </tr>
        <?php
        $i++;
        }
        ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/theme/todayorderstable.blade.php ENDPATH**/ ?>