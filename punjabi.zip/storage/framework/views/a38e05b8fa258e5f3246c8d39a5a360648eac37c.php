<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>#</th>
            <th><?php echo e(trans('labels.name')); ?></th>
            <th><?php echo e(trans('labels.rating')); ?></th>
            <th><?php echo e(trans('labels.comment')); ?></th>
            <th><?php echo e(trans('labels.created_at')); ?></th>
            <th><?php echo e(trans('labels.action')); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php
        $i=1;
        foreach ($getreview as $reviews) {
        ?>
        <tr id="dataid<?php echo e($reviews->id); ?>">
            <td><?php echo e($i); ?></td>
            <td><?php echo e($reviews['users']->name); ?></td>
            <td><i class="fa fa-star"></i> <?php echo e($reviews->ratting); ?></td>
            <td><?php echo e($reviews->comment); ?></td>
            <td><?php echo e($reviews->created_at); ?></td>
            <td>
                <span>
                    <a href="#" data-toggle="tooltip" data-placement="top" onclick="DeleteData('<?php echo e($reviews->id); ?>')" title="" data-original-title="<?php echo e(trans('labels.delete')); ?>">
                        <span class="badge badge-danger"><?php echo e(trans('labels.delete')); ?></span>
                    </a>
                </span>
            </td>
        </tr>
        <?php
        $i++;
        }
        ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/theme/reviewstable.blade.php ENDPATH**/ ?>