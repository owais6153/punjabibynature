<?php echo $__env->make('front.theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="product-prev-sec product-list-sec">
    <div class="container">
        <div class="product-rev-wrap">
            <div class="cat-aside">
                <h3 class="text-center"><?php echo e(trans('labels.categories')); ?></h3>
                <div class="cat-aside-wrap">
                    <?php $__currentLoopData = $getcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(URL::to('/product/'.$category->id)); ?>" class="cat-check border-top-no <?php if(request()->id == $category->id): ?> active <?php endif; ?>">
                        <img src='<?php echo asset("storage/app/public/images/category/".$category->image); ?>' alt="">
                        <p><?php echo e($category->category_name); ?></p>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="cat-product">
                <div class="cart-pro-head">
                    <h2 class="sec-head"><?php echo e(trans('labels.our_products')); ?></h2>
                    <div class="btn-wrap" data-toggle="buttons">
                        <label id="list" class="btn">
                            <input type="radio" name="layout" id="layout1"> <i class="fas fa-list"></i>
                        </label>
                        <label id="grid" class="btn active">
                            <input type="radio" name="layout" id="layout2" checked> <i class="fas fa-th"></i>
                        </label>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $getitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-4 col-md-6">
                        <div class="pro-box">
                            <div class="pro-img">
                                <?php $__currentLoopData = $item->variation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($value->sale_price > 0): ?>
                                        <div class="ribbon-wrapper">
                                            <div class="ribbon">ON SALE</div>
                                        </div>
                                    <?php endif; ?>
                                    <?php break; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(URL::to('product-details/'.$item->id)); ?>">
                                    <img src='<?php echo e($item["itemimage"]->image); ?>' alt="">
                                </a>
                                <?php if(Session::get('id')): ?>
                                    <?php if($item->is_favorite == 1): ?>
                                        <i class="fas fa-heart i"></i>
                                    <?php else: ?>
                                        <i class="fal fa-heart i" onclick="MakeFavorite('<?php echo e($item->id); ?>','<?php echo e(Session::get('id')); ?>')"></i>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <div class="product-details-wrap">
                                <div class="product-details">
                                    <a href="<?php echo e(URL::to('product-details/'.$item->id)); ?>">
                                        <h4><?php echo e($item->item_name); ?></h4>
                                    </a>
                                    <p class="pro-pricing">
                                        <?php $__currentLoopData = $item->variation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($getdata->currency); ?><?php echo e(number_format($value->product_price, 2)); ?>

                                            <?php break; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </p>
                                </div>
                                <div class="product-details">
                                    <p><?php echo e(Str::limit($item->item_description, 60)); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <nav aria-label="Page navigation example">
                    <?php if($getitem->hasPages()): ?>
                    <ul class="pagination" role="navigation">
                        
                        <?php if($getitem->onFirstPage()): ?>
                            <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                                <span class="page-link" aria-hidden="true">&lsaquo;</span>
                            </li>
                        <?php else: ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($getitem->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">&lsaquo;</a>
                            </li>
                        <?php endif; ?>

                        <?php
                            $start = $getitem->currentPage() - 2; // show 3 pagination links before current
                            $end = $getitem->currentPage() + 2; // show 3 pagination links after current
                            if($start < 1) {
                                $start = 1; // reset start to 1
                                $end += 1;
                            } 
                            if($end >= $getitem->lastPage() ) $end = $getitem->lastPage(); // reset end to last page
                        ?>

                        <?php if($start > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($getitem->url(1)); ?>"><?php echo e(1); ?></a>
                            </li>
                            <?php if($getitem->currentPage() != 4): ?>
                                
                                <li class="page-item disabled" aria-disabled="true"><span class="page-link">...</span></li>
                            <?php endif; ?>
                        <?php endif; ?>
                            <?php for($i = $start; $i <= $end; $i++): ?>
                                <li class="page-item <?php echo e(($getitem->currentPage() == $i) ? ' active' : ''); ?>">
                                    <a class="page-link" href="<?php echo e($getitem->url($i)); ?>"><?php echo e($i); ?></a>
                                </li>
                            <?php endfor; ?>
                        <?php if($end < $getitem->lastPage()): ?>
                            <?php if($getitem->currentPage() + 3 != $getitem->lastPage()): ?>
                                
                                <li class="page-item disabled" aria-disabled="true"><span class="page-link">...</span></li>
                            <?php endif; ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($getitem->url($getitem->lastPage())); ?>"><?php echo e($getitem->lastPage()); ?></a>
                            </li>
                        <?php endif; ?>

                        
                        <?php if($getitem->hasMorePages()): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($getitem->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">&rsaquo;</a>
                            </li>
                        <?php else: ?>
                            <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                                <span class="page-link" aria-hidden="true">&rsaquo;</span>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <?php endif; ?>
                </nav>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('front.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/front/product.blade.php ENDPATH**/ ?>