<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>#</th>
            <th><?php echo e(trans('labels.addons_name')); ?></th>
            <th><?php echo e(trans('labels.price')); ?></th>
            <th><?php echo e(trans('labels.created_at')); ?></th>
            <th><?php echo e(trans('labels.status')); ?></th>
            <th><?php echo e(trans('labels.action')); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($getaddons as $addons) {
        ?>
        <tr id="dataid<?php echo e($addons->id); ?>">
            <td><?php echo e($addons->id); ?></td>
            <td><?php echo e($addons->name); ?></td>
            <td><?php echo e(Auth::user()->currency); ?><?php echo e(number_format($addons->price, 2)); ?></td>
            <td><?php echo e($addons->created_at); ?></td>
            <?php if(env('Environment') == 'sendbox'): ?>
                <td>
                    <?php if($addons->is_available == 1): ?>
                        <a class="badge badge-success px-2" onclick="myFunction()" style="color: #fff;"><?php echo e(trans('labels.active')); ?></a>
                    <?php else: ?>
                        <a class="badge badge-danger px-2" onclick="myFunction()" style="color: #fff;"><?php echo e(trans('labels.deactive')); ?></a>
                    <?php endif; ?>
                </td>
                <td>
                    <span>
                        <a href="#" data-toggle="tooltip" data-placement="top" onclick="GetData('<?php echo e($addons->id); ?>')" title="" data-original-title="<?php echo e(trans('labels.edit')); ?>">
                            <span class="badge badge-success"><?php echo e(trans('labels.edit')); ?></span>
                        </a>

                        <a class="badge badge-danger px-2" onclick="myFunction()" style="color: #fff;"><?php echo e(trans('labels.delete')); ?></a>
                    </span>
                </td>
            <?php else: ?>
                <td>
                    <?php if($addons->is_available == 1): ?>
                        <a class="badge badge-success px-2" onclick="StatusUpdate('<?php echo e($addons->id); ?>','2')" style="color: #fff;"><?php echo e(trans('labels.active')); ?></a>
                    <?php else: ?>
                        <a class="badge badge-danger px-2" onclick="StatusUpdate('<?php echo e($addons->id); ?>','1')" style="color: #fff;"><?php echo e(trans('labels.deactive')); ?></a>
                    <?php endif; ?>
                </td>
                <td>
                    <span>
                        <a href="#" data-toggle="tooltip" data-placement="top" onclick="GetData('<?php echo e($addons->id); ?>')" title="" data-original-title="<?php echo e(trans('labels.edit')); ?>">
                            <span class="badge badge-success"><?php echo e(trans('labels.edit')); ?></span>
                        </a>

                        <a class="badge badge-danger px-2" onclick="Delete('<?php echo e($addons->id); ?>')" style="color: #fff;"><?php echo e(trans('labels.delete')); ?></a>
                    </span>
                </td>
            <?php endif; ?>
        </tr>
        <?php
        }
        ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/theme/addonstable.blade.php ENDPATH**/ ?>