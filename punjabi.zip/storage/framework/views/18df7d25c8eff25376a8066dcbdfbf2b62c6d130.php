<?php $__env->startSection('content'); ?>

<div class="row page-titles mx-0">
    <div class="col p-md-0">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/admin/home')); ?>"><?php echo e(trans('labels.dashboard')); ?></a></li>
            <li class="breadcrumb-item active"><a href="javascript:void(0)"><?php echo e(trans('labels.orders')); ?></a></li>
        </ol>
    </div>
</div>
<!-- row -->

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title"><?php echo e(trans('labels.all_orders')); ?></h4>
                    <div class="table-responsive" id="table-display">
                        <?php echo $__env->make('theme.orderstable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form method="post" id="assign">
            <?php echo e(csrf_field()); ?>

            <div class="modal-body">
                <div class="form-group">
                    <label for="category_id" class="col-form-label"><?php echo e(trans('labels.order_id')); ?>:</label>
                    <input type="text" class="form-control" id="bookId" name="bookId" readonly="">
                </div>
                <div class="form-group">
                    <label for="category_id" class="col-form-label"><?php echo e(trans('messages.select_driver')); ?>:</label>
                    <select class="form-control" name="driver_id" id="driver_id" required="">
                        <option value=""><?php echo e(trans('messages.select_driver')); ?></option>
                        <?php $__currentLoopData = $getdriver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($driver->id); ?>"><?php echo e($driver->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(trans('labels.close')); ?></button>
                <button type="button" class="btn btn-primary" onclick="assign()" data-dismiss="modal"><?php echo e(trans('labels.save')); ?></button>
            </div>
            </form>
        </div>

    </div>
</div>

<!-- #/ container -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $('.table').dataTable({
      aaSorting: [[0, 'DESC']]
    });

    function StatusUpdate(id,status) {
        swal({
            title: "<?php echo e(trans('messages.are_you_sure')); ?>",
            type: 'warning',
            showCancelButton: true,
            confirmButtonText: "<?php echo e(trans('messages.yes')); ?>",
            cancelButtonText: "<?php echo e(trans('messages.no')); ?>",
            closeOnConfirm: false,
            closeOnCancel: false,
            showLoaderOnConfirm: true,
        },
        function(isConfirm) {
            if (isConfirm) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url:"<?php echo e(URL::to('admin/orders/update')); ?>",
                    data: {
                        id: id,
                        status: status
                    },
                    method: 'POST', //Post method,
                    dataType: 'json',
                    success: function(response) {
                        if (response == 1) {
                            location.reload();
                        } else {
                            swal("Cancelled", "<?php echo e(trans('messages.wrong')); ?> :(", "error");
                        }
                    },
                    error: function(e) {
                        swal("Cancelled", "<?php echo e(trans('messages.wrong')); ?> :(", "error");
                    }
                });
            } else {
                swal("Cancelled", "<?php echo e(trans('messages.record_safe')); ?> :)", "error");
            }
        });
    }

    $(document).on("click", ".open-AddBookDialog", function () {
         var myBookId = $(this).data('id');
         $(".modal-body #bookId").val( myBookId );
    });

    function assign(){     
        var bookId=$("#bookId").val();
        var driver_id = $('#driver_id').val();
        var CSRF_TOKEN = $('input[name="_token"]').val();
        $('#preloader').show();
        $.ajax({
            headers: {
                'X-CSRF-Token': CSRF_TOKEN 
            },
            url:"<?php echo e(URL::to('admin/orders/assign')); ?>",
            method:'POST',
            data:{'bookId':bookId,'driver_id':driver_id},
            dataType:"json",
            success:function(data){
                $('#preloader').hide();
                if (data == 1) {
                    location.reload();
                }
            },error:function(data){
               
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/orders.blade.php ENDPATH**/ ?>