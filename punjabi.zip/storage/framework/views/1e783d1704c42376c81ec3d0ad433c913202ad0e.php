<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>#</th>          
            <th>Ingredient type</th>
            <th>Created at</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($getingredientTypes as $ingredientsType) {
        ?>
        <tr id="dataid<?php echo e($ingredientsType->id); ?>">
            <td><?php echo e($ingredientsType->id); ?></td>
            <td><?php echo e($ingredientsType->name); ?></td>
            <td><?php echo e($ingredientsType->created_at); ?></td>
            <?php if(env('Environment') == 'sendbox'): ?>
                <td>
                    <span>
                        <a href="#" data-toggle="tooltip" data-placement="top" onclick="GetData('<?php echo e($ingredientsType->id); ?>')" title="" data-original-title="Edit">
                            <span class="badge badge-success">Edit</span>
                        </a>

                        <a class="badge badge-danger px-2" onclick="myFunction()" style="color: #fff;">Delete</a>
                    </span>
                </td>
            <?php else: ?>
                <td>
                    <span>
                        <a href="#" data-toggle="tooltip" data-placement="top" onclick="GetData('<?php echo e($ingredientsType->id); ?>')" title="" data-original-title="Edit">
                            <span class="badge badge-success">Edit</span>
                        </a>

                        <a class="badge badge-danger px-2" onclick="Delete('<?php echo e($ingredientsType->id); ?>')" style="color: #fff;">Delete</a>
                    </span>
                </td>
            <?php endif; ?>
        </tr>
        <?php
        }
        ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/theme/ingredienttypetable.blade.php ENDPATH**/ ?>