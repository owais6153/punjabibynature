

<?php $__env->startSection('content'); ?>

<div class="row page-titles mx-0">
    <div class="col p-md-0">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/admin/home')); ?>"><?php echo e(trans('labels.dashboard')); ?></a></li>
            <li class="breadcrumb-item active"><a href="javascript:void(0)"><?php echo e(trans('labels.reviews')); ?></a></li>
        </ol>
    </div>
</div>
<!-- row -->

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <span id="message"></span>
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title"><?php echo e(trans('labels.all_reviews')); ?></h4>
                    <div class="table-responsive" id="table-display">
                        <?php echo $__env->make('theme.reviewstable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- #/ container -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $('.table').dataTable({
      aaSorting: [[0, 'DESC']]
    });
    function DeleteData(id) {
        swal({
            title: "<?php echo e(trans('messages.are_you_sure')); ?>",
            type: 'warning',
            showCancelButton: true,
            confirmButtonText: "<?php echo e(trans('messages.yes')); ?>",
            cancelButtonText: "<?php echo e(trans('messages.no')); ?>",
            closeOnConfirm: false,
            closeOnCancel: false,
            showLoaderOnConfirm: true,
        },
        function(isConfirm) {
            if (isConfirm) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url:"<?php echo e(URL::to('admin/reviews/destroy')); ?>",
                    data: {
                        id: id
                    },
                    method: 'POST',
                    success: function(response) {
                        if (response == 1) {
                            $('#dataid'+id).remove();
                            swal.close();
                        } else {
                            swal("Cancelled", "<?php echo e(trans('messages.wrong')); ?> :(", "error");
                        }
                    },
                    error: function(e) {
                        swal("Cancelled", "<?php echo e(trans('messages.wrong')); ?> :(", "error");
                    }
                });
            } else {
                swal("Cancelled", "<?php echo e(trans('messages.record_safe')); ?> :)", "error");
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/reviews.blade.php ENDPATH**/ ?>