<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>#</th>
            <th><?php echo e(trans('labels.profile_image')); ?></th>
            <th><?php echo e(trans('labels.name')); ?></th>
            <th><?php echo e(trans('labels.email')); ?></th>
            <th><?php echo e(trans('labels.mobile')); ?></th>
            <th><?php echo e(trans('labels.created_at')); ?></th>
            <th><?php echo e(trans('labels.action')); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $getdriver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="dataid<?php echo e($driver->id); ?>">
            <td><?php echo e($driver->id); ?></td>
            <td><img src='<?php echo asset("storage/app/public/images/profile/".$driver->profile_image); ?>' style="width: 100px;"></td>
            <td><?php echo e($driver->name); ?></td>
            <td><?php echo e($driver->email); ?></td>
            <td><?php echo e($driver->mobile); ?></td>
            <td><?php echo e($driver->created_at); ?></td>
            <td>
                <a href="#" data-toggle="tooltip" data-placement="top" onclick="GetData('<?php echo e($driver->id); ?>')" title="" data-original-title="<?php echo e(trans('labels.edit')); ?>">
                    <span class="badge badge-success"><?php echo e(trans('labels.edit')); ?></span>
                </a>
                <?php if(env('Environment') == 'sendbox'): ?>
                    <a href="#" data-toggle="tooltip" data-placement="top" onclick="myFunction()" title="" data-original-title="<?php echo e(trans('labels.block')); ?>">
                        <span class="badge badge-danger"><?php echo e(trans('labels.block')); ?></span>
                    </a>
                <?php else: ?>
                    <?php if($driver->is_available == '1'): ?>
                        <a class="badge badge-danger px-2" onclick="StatusUpdate('<?php echo e($driver->id); ?>','2')" style="color: #fff;"><?php echo e(trans('labels.block')); ?></a>
                    <?php else: ?>
                        <a class="badge badge-primary px-2" onclick="StatusUpdate('<?php echo e($driver->id); ?>','1')" style="color: #fff;"><?php echo e(trans('labels.unblock')); ?></a>
                    <?php endif; ?>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/theme/drivertable.blade.php ENDPATH**/ ?>