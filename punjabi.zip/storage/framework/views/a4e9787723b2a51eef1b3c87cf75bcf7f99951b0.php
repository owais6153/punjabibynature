<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>#</th>          
            <th>Group Name</th>
            <th>Created at</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($addonGroups as $addonGroup) {
        ?>
        <tr id="dataid<?php echo e($addonGroup->id); ?>">
            <td><?php echo e($addonGroup->id); ?></td>
            <td><?php echo e($addonGroup->name); ?></td>
            <td><?php echo e($addonGroup->created_at); ?></td>
            <?php if(env('Environment') == 'sendbox'): ?>
                <td>
                    <span>
                        <a href="#" data-toggle="tooltip" data-placement="top" onclick="GetData('<?php echo e($addonGroup->id); ?>')" title="" data-original-title="Edit">
                            <span class="badge badge-success">Edit</span>
                        </a>

                        <a class="badge badge-danger px-2" onclick="myFunction()" style="color: #fff;">Delete</a>
                    </span>
                </td>
            <?php else: ?>
                <td>
                    <span>
                        <a href="#" data-toggle="tooltip" data-placement="top" onclick="GetData('<?php echo e($addonGroup->id); ?>')" title="" data-original-title="Edit">
                            <span class="badge badge-success">Edit</span>
                        </a>

                        <a class="badge badge-danger px-2" onclick="Delete('<?php echo e($addonGroup->id); ?>')" style="color: #fff;">Delete</a>
                    </span>
                </td>
            <?php endif; ?>
        </tr>
        <?php
        }
        ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/theme/addonGroupsTable.blade.php ENDPATH**/ ?>