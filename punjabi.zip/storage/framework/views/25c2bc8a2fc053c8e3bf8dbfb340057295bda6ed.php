<?php echo $__env->make('front.theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="product-details-sec">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="product-details-img owl-carousel owl-theme">
                    <?php $__currentLoopData = $getimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <a data-fancybox="gallery" href="<?php echo e($images->image); ?>">
                            <img src='<?php echo e($images->image); ?>' alt="">
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-lg-7 pro-details-display">
                <div class="pro-details-name-wrap">
                    <h3 class="sec-head mt-0"><?php echo e($getitem->item_name); ?></h3>
                    <?php $__currentLoopData = $getitem->variation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="price" id="price" value="<?php echo e($value->product_price); ?>">
                        <?php break; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Session::get('id')): ?>
                        <?php if($getitem->is_favorite == 1): ?>
                            <i class="fas fa-heart i"></i>
                        <?php else: ?>
                            <i class="fal fa-heart i" onclick="MakeFavorite('<?php echo e($getitem->id); ?>','<?php echo e(Session::get('id')); ?>')"></i>
                        <?php endif; ?>
                    <?php else: ?>
                        <a class="i" href="<?php echo e(URL::to('/signin')); ?>"><i class="fal fa-heart i"></i></a>
                    <?php endif; ?>
                </div>

                <small><?php echo e($getitem['category']->category_name); ?></small>

                <?php if(count($getitem['variation']) > 1): ?>

                    <?php echo e(trans('messages.select_variation')); ?>

                    <select class="form-control readers" name="variation" id="variation" style="width: 50%">
                        <?php $__currentLoopData = $getitem['variation']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($variation->id); ?>" data-price="<?php echo e($variation->product_price); ?>" data-saleprice="<?php echo e($variation->sale_price); ?>" data-variation="<?php echo e($variation->variation); ?>"><?php echo e($variation->variation); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php else: ?>

                    <select class="form-control readers" name="variation" id="variation" style="width: 50%; display: none;">
                        <?php $__currentLoopData = $getitem['variation']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($variation->id); ?>" data-price="<?php echo e($variation->product_price); ?>" data-saleprice="<?php echo e($variation->sale_price); ?>" data-variation="<?php echo e($variation->variation); ?>"><?php echo e($variation->variation); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                <?php endif; ?>

             
     


                <div class="extra-food-wrap">
                <!-- Ingredients -->
                    <?php if(isset($getingredientsByTypes[0]->name)): ?> 
                        <div id="ingredientsOptions" class="ingredientsOptions"> 
                        <?php $__currentLoopData = $getingredientsByTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredientsByType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="selectIngredients" >
                                <h4><?php echo e($ingredientsByType->name); ?></h4>

                                <p>You can select <?php echo e($ingredientsByType->available_ing_option); ?> option<?php echo ($ingredientsByType->available_ing_option > 1 || $ingredientsByType->available_ing_option == 'all')? 's' : '' ; ?>.</p>
                                 <ul class="list-unstyled extra-food" ingredient_type="<?php echo e($ingredientsByType->name); ?>">
                                 <?php $__currentLoopData = $ingredientsByType->ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredientsItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="<?php echo e(($ingredientsByType->available_ing_option > 1 || $ingredientsByType->available_ing_option == 'all')? '' : 'Radio'); ?>">
                                    <input  class="Checkbox ingredients" type="<?php echo e(($ingredientsByType->available_ing_option > 1 || $ingredientsByType->available_ing_option == 'all')? 'checkbox' : 'radio'); ?>" name="ingredients['<?php echo e($ingredientsByType->name); ?>']" value="<?php echo e($ingredientsItems->id); ?>" data-option-allowed="<?php echo e($ingredientsByType->available_ing_option); ?>" ingredient_name="<?php echo e($ingredientsItems->ingredients); ?>" >
                                    <p><?php echo e($ingredientsItems->ingredients); ?></p>
                                </li>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </ul>
                             </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <!-- End Ingredients -->    
                    <!-- Paid Group Addon -->
                    <?php if(isset($getAddonsByGroups[0]->name)): ?> 
                        <?php $__currentLoopData = $getAddonsByGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getAddonsByGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($getAddonsByGroup->price != 0): ?>
                                <ul class="list-unstyled extra-food addon_group paid" data-price="<?php echo e($getAddonsByGroup->price); ?>" group_name="<?php echo e($getAddonsByGroup->name); ?>">
                                    <h3><?php echo e($getAddonsByGroup->name); ?> : <?php echo e($getdata->currency); ?><?php echo e(number_format($getAddonsByGroup->price, 2)); ?></h3>
                                    <p>You can select <?php echo e($getAddonsByGroup->available_add_option); ?> option<?php echo ($getAddonsByGroup->available_add_option > 1 || $getAddonsByGroup->available_add_option == 'all')? 's' : '' ; ?>.</p>
                                    <?php $__currentLoopData = $getAddonsByGroup->addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="<?php echo e(($getAddonsByGroup->available_add_option > 1 || $getAddonsByGroup->available_add_option == 'all')? '' : 'Radio'); ?>">
                                            <input type="<?php echo e(($getAddonsByGroup->available_add_option > 1 || $getAddonsByGroup->available_add_option == 'all')? 'checkbox' : 'radio'); ?>" name="addons['<?php echo e($getAddonsByGroup->name); ?>'][]" class="Checkbox group_addon" value="<?php echo e($addon->id); ?>" data-option-allowed="<?php echo e($getAddonsByGroup->available_add_option); ?>" addon_name="<?php echo e($addon->name); ?>">
                                            <p><?php echo e($addon->name); ?></p>
                                       </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    <?php endif; ?>                   
                    <!-- End Paid Group Addon -->
                    <!--  Free Group Addon -->
                    <?php if(isset($getAddonsByGroups[0]->name)): ?> 
                        <?php $__currentLoopData = $getAddonsByGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getAddonsByGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($getAddonsByGroup->price == 0): ?>
                            <ul class="list-unstyled extra-food addon_group" group_name="<?php echo e($getAddonsByGroup->name); ?>"  data-price="<?php echo e($getAddonsByGroup->price); ?>">
                                <h3><?php echo e($getAddonsByGroup->name); ?></h3>
                                 <p>You can select <?php echo e($getAddonsByGroup->available_add_option); ?> option<?php echo ($getAddonsByGroup->available_add_option > 1 || $getAddonsByGroup->available_add_option == 'all')? 's' : '' ; ?>.</p>
                                <?php $__currentLoopData = $getAddonsByGroup->addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="<?php echo e(($getAddonsByGroup->available_add_option > 1 || $getAddonsByGroup->available_add_option == 'all')? '' : 'Radio'); ?>">
                                        <input type="<?php echo e(($getAddonsByGroup->available_add_option > 1 || $getAddonsByGroup->available_add_option == 'all')? 'checkbox' : 'radio'); ?>" name="addons['<?php echo e($getAddonsByGroup->name); ?>'][]" class="Checkbox group_addon" value="<?php echo e($addon->id); ?>" data-option-allowed="<?php echo e($getAddonsByGroup->available_add_option); ?>"  addon_name="<?php echo e($addon->name); ?>">
                                        <p><?php echo e($addon->name); ?></p>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <!--  End Free Group Addon -->
                    <!-- Free Single Addon -->
                    <?php if(count($freeaddons['value']) != 0): ?>
                        <ul class="list-unstyled extra-food single-addon">
                            <?php if($freeaddons['value'] != ""): ?>
                                <h3><?php echo e(trans('labels.free_addons')); ?></h3>
                                <?php $__currentLoopData = $freeaddons['value']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addons): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <input type="checkbox" name="addons[]" class="Checkbox single_addon" value="<?php echo e($addons->id); ?>" price="<?php echo e($addons->price); ?>" addons_name="<?php echo e($addons->name); ?>">
                                    <p><?php echo e($addons->name); ?></p>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>

                            <?php endif; ?>
                        </ul>
                    <?php endif; ?>
                    <!-- End Free Single Addon -->
                    <!-- Paid Single Addon -->
                    <?php if(count($paidaddons['value']) != 0): ?>
                        <ul class="list-unstyled extra-food single-addon">
                            <h3><?php echo e(trans('labels.paid_addons')); ?></h3>
                            <div id="pricelist">
                            <?php $__currentLoopData = $paidaddons['value']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addons): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <input type="checkbox" name="addons[]" class="Checkbox single_addon" value="<?php echo e($addons->id); ?>" price="<?php echo e($addons->price); ?>" addons_name="<?php echo e($addons->name); ?>">
                                <p><?php echo e($addons->name); ?> : <?php echo e($getdata->currency); ?><?php echo e(number_format($addons->price, 2)); ?></p>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </ul>
                    <?php endif; ?>
                    <!-- End Paid Single Addon -->
                    <div class="pro-details-add-wrap">
                        <p class="pricing">
                            <?php $__currentLoopData = $getitem->variation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h3 id="temp-pricing" class="product-price"><?php echo e($getdata->currency); ?><?php echo e(number_format($value->product_price,2)); ?></h3>
                                <?php if($value->sale_price > 0): ?>
                                    <h3 id="card2-oldprice"><?php echo e($getdata->currency); ?><?php echo e(number_format($value->sale_price,2)); ?></h3>
                                <?php endif; ?>
                                <?php break; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p class="card2-oldprice-show"></p>
                            <?php if($getitem->tax > 0): ?>
                                <p style="color: #ff0000;" class="mt-3">+ <?php echo e($getitem->tax); ?>% Additional Tax</p>
                            <?php else: ?>
                                <p style="color: #03a103;" class="mt-3">Inclusive of all taxes</p>
                            <?php endif; ?>
                        </p>

                        <p class="open-time"><i class="far fa-clock"></i> <?php echo e($getitem->delivery_time); ?></p>
                        <?php if(Session::get('id')): ?>
                            <?php if($getitem->item_status == '1'): ?>
                                <button class="btn" onclick="AddtoCart('<?php echo e($getitem->id); ?>','<?php echo e(Session::get('id')); ?>')"><?php echo e(trans('labels.add_to_cart')); ?></button>
                            <?php else: ?> 
                                <button class="btn" disabled=""><?php echo e(trans('labels.unavailable')); ?></button>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($getitem->item_status == '1'): ?>
                                <button class="btn" onclick="AddtoCart('<?php echo e($getitem->id); ?>','guest')"><?php echo e(trans('labels.add_to_cart')); ?></button>
                            <?php else: ?> 
                                <button class="btn" disabled=""><?php echo e(trans('labels.unavailable')); ?></button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <textarea id="item_notes" name="item_notes" placeholder="Write Notes..."></textarea>
            </div>

            
            <div class="col-12">
                
                <h4 class="sec-head"><?php echo e(trans('labels.description')); ?></h4>
                <p><?php echo e($getitem->item_description); ?></p>

               
            </div>

            <div class="col-12">
                <h2 class="sec-head text-center"><?php echo e(trans('labels.related_food')); ?></h2>
                <div class="pro-ref-carousel owl-carousel owl-theme">
                    <?php $__currentLoopData = $relatedproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="pro-box">
                            <div class="pro-img">
                                <?php $__currentLoopData = $item->variation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($value->sale_price > 0): ?>
                                        <div class="ribbon-wrapper">
                                            <div class="ribbon">ON SALE</div>
                                        </div>
                                    <?php endif; ?>
                                    <?php break; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(URL::to('product-details/'.$item->id)); ?>">
                                    <img src='<?php echo e($item["itemimage"]->image); ?>' alt="">
                                </a>
                                <?php if(Session::get('id')): ?>
                                    <?php if($item->is_favorite == 1): ?>
                                        <i class="fas fa-heart i"></i>
                                    <?php else: ?>
                                        <i class="fal fa-heart i"  onclick="MakeFavorite('<?php echo e($item->id); ?>','<?php echo e(Session::get('id')); ?>')"></i>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a href="<?php echo e(URL::to('/signin')); ?>"><i class="fal fa-heart i"></i></a>
                                <?php endif; ?>
                            </div>
                            <div class="product-details-wrap">
                                <div class="product-details">
                                    <a href="<?php echo e(URL::to('product-details/'.$item->id)); ?>">
                                        <h4><?php echo e($item->item_name); ?></h4>
                                    </a>
                                    <p class="pro-pricing">
                                        <?php $__currentLoopData = $item->variation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($getdata->currency); ?><?php echo e(number_format($value->product_price,2)); ?>

                                            <?php break; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </p>
                                </div>
                                <div class="product-details">
                                    <p><?php echo e(Str::limit($item->item_description, 60)); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('front.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript">


$('input[type="checkbox"]').change(function() {
    let option_allowed = $(this).attr('data-option-allowed');
    if (option_allowed != 'all') {
        let attr_name = $(this).attr('name');
        if($(this).is(':checked')){
            if($('input[name="'+attr_name+'"]:checked').length == option_allowed){
                $('input[name="'+attr_name+'"]:not(:checked)').attr('disabled', 'disabled');
                $('input[name="'+attr_name+'"]:not(:checked)').parents('li').addClass('disabled');
            }
        }
        else{
            $('input[name="'+attr_name+'"]').removeAttr('disabled');
            $('input[name="'+attr_name+'"]:not(:checked)').parents('li').removeClass('disabled');
        }
    }
});


$('.single-addon input[type="checkbox"]').change(function() {
    "use strict";    
    $('#temp-pricing').hide();
    var total = parseFloat($("#price").val()); 

    if($(this).is(':checked')){

        total += parseFloat($(this).attr('price')) || 0;

    }

    else{

        total -= parseFloat($(this).attr('price')) || 0;

    }

    $('p.pricing').text('<?php echo e($getdata->currency); ?>'+total.toFixed(2));

    $('#price').val(total.toFixed(2));

})


$('.addon_group.paid input').change(function() {
    "use strict";
    $('#temp-pricing').hide();
    var total = parseFloat($("#price").val()); 
    var attrName = $(this).attr('name');
    if($(this).attr('type') == 'checkbox'){
        if($(this).is(':checked')){
            if (!$(this).parents('ul').hasClass('counted')) {
                total += parseFloat($(this).parents('ul').attr('data-price')) || 0;
                $(this).parents('ul').addClass('counted');
            }
        }
        else{
            if ($(this).parents('ul').hasClass('counted') && $('input[name="'+attrName+'"]:checked').length == 0) {
                total -= parseFloat($(this).parents('ul').attr('data-price')) || 0;
                $(this).parents('ul').removeClass('counted');
            }
        }
    }
    else if($(this).attr('type') == 'radio'){
         $(this).parents('ul').addClass('counted');
         total += parseFloat($(this).parents('ul').attr('data-price')) || 0;
    }
    $('p.pricing').text('<?php echo e($getdata->currency); ?>'+total.toFixed(2));

    $('#price').val(total.toFixed(2));

})


// ------------------------

$(".readers").change(function() {
    "use strict";
    $('input[type=checkbox]').prop('checked',false);
    $(".readers option:selected").each(function() {
        $('#temp-pricing').hide();
        $('#card2-oldprice').hide();
        var ttl = parseFloat($(this).attr('data-price'));
        var ttlsaleprice = parseFloat($(this).attr('data-saleprice').replace(/"|\,|\./g, ''));
        console.log(ttl);
        $('p.pricing').text('<?php echo e($getdata->currency); ?>'+ttl.toFixed(2));
        console.log(ttl.toFixed(2));
        if (ttlsaleprice > 0) {
            $('p.card2-oldprice-show').text('<?php echo e($getdata->currency); ?>'+ttlsaleprice.toFixed(2));
        }
        
        $('#price').val($(this).attr('data-price'));
    });
});
$(document).ready(function(){
    $('.readers').prop('selectedIndex',0);
});

</script><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/front/product-details.blade.php ENDPATH**/ ?>