<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>#</th>
            <th><?php echo e(trans('labels.category')); ?></th>
            <th><?php echo e(trans('labels.item_name')); ?></th>
            <th><?php echo e(trans('labels.tax')); ?></th>
            <th><?php echo e(trans('labels.delivery_time')); ?></th>
            <th><?php echo e(trans('labels.status')); ?></th>
            <th><?php echo e(trans('labels.action')); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($getitem as $item) {
        ?>
        <tr id="dataid<?php echo e($item->id); ?>">
            <td><?php echo e($item->id); ?></td>
            <td><?php echo e(@$item['category']->category_name); ?></td>
            <td><?php echo e($item->item_name); ?></td>
            <td><?php echo e($item->tax, 2); ?>%</td>
            <td><?php echo e($item->delivery_time); ?></td>
            <?php if(env('Environment') == 'sendbox'): ?>
                <td>
                    <?php if($item->item_status == 1): ?>
                        <a class="badge badge-success px-2" onclick="myFunction()" style="color: #fff;"><?php echo e(trans('labels.active')); ?></a>
                    <?php else: ?>
                        <a class="badge badge-danger px-2" onclick="myFunction()" style="color: #fff;"><?php echo e(trans('labels.deactive')); ?></a>
                    <?php endif; ?>
                </td>
                <td>
                    <span>
                        <a data-toggle="tooltip" href="<?php echo e(URL::to('admin/edititem/'.$item->id)); ?>" data-original-title="<?php echo e(trans('labels.edit')); ?>">
                            <span class="badge badge-success"><?php echo e(trans('labels.edit')); ?></span>
                        </a>

                        <a class="badge badge-danger px-2" onclick="myFunction()" style="color: #fff;"><?php echo e(trans('labels.delete')); ?></a>
                    </span>
                </td>
            <?php else: ?>
                <td>
                    <?php if($item->item_status == 1): ?>
                        <a class="badge badge-success px-2" onclick="StatusUpdate('<?php echo e($item->id); ?>','2')" style="color: #fff;"><?php echo e(trans('labels.active')); ?></a>
                    <?php else: ?>
                        <a class="badge badge-danger px-2" onclick="StatusUpdate('<?php echo e($item->id); ?>','1')" style="color: #fff;"><?php echo e(trans('labels.deactive')); ?></a>
                    <?php endif; ?>
                </td>
                <td>
                    <span>
                        <a data-toggle="tooltip" href="<?php echo e(URL::to('admin/edititem/'.$item->id)); ?>" data-original-title="<?php echo e(trans('labels.edit')); ?>">
                            <span class="badge badge-success"><?php echo e(trans('labels.edit')); ?></span>
                        </a>

                        <a class="badge badge-danger px-2" onclick="Delete('<?php echo e($item->id); ?>')" style="color: #fff;"><?php echo e(trans('labels.delete')); ?></a>
                    </span>
                </td>
            <?php endif; ?>
        </tr>
        <?php
        }
        ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/theme/itemtable.blade.php ENDPATH**/ ?>