<?php $__env->startSection('content'); ?>

<div class="row page-titles mx-0">
    <div class="col p-md-0">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/admin/home')); ?>"><?php echo e(trans('labels.dashboard')); ?></a></li>
            <li class="breadcrumb-item active"><a href="javascript:void(0)"><?php echo e(trans('labels.drivers')); ?></a></li>
        </ol>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addDriver" data-whatever="@addDriver"><?php echo e(trans('labels.add_driver')); ?></button>
        <!-- Add Driver -->
        <div class="modal fade" id="addDriver" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><?php echo e(trans('labels.add_driver')); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    
                    <form id="add_driver" enctype="multipart/form-data">
                    <div class="modal-body">
                        <span id="msg"></span>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name" class="col-form-label"><?php echo e(trans('labels.name')); ?></label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="<?php echo e(trans('messages.enter_name')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="email" class="col-form-label"><?php echo e(trans('labels.email')); ?></label>
                            <input type="text" class="form-control" name="email" placeholder="<?php echo e(trans('messages.enter_email')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="mobile" class="col-form-label"><?php echo e(trans('labels.mobile')); ?></label>
                            <input type="text" class="form-control" name="mobile" placeholder="<?php echo e(trans('messages.enter_mobile')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="password" class="col-form-label"><?php echo e(trans('labels.password')); ?></label>
                            <input type="password" class="form-control" name="password" id="password" placeholder="<?php echo e(trans('messages.enter_password')); ?>">
                        </div>           
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(trans('labels.close')); ?></button>
                        <?php if(env('Environment') == 'sendbox'): ?>
                            <button type="button" class="btn btn-primary" onclick="myFunction()"><?php echo e(trans('labels.save')); ?></button>
                        <?php else: ?>
                            <button type="submit" class="btn btn-primary"><?php echo e(trans('labels.save')); ?></button>
                        <?php endif; ?>
                    </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Driver -->
        <div class="modal fade" id="EditDriver" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabeledit" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <form method="post" name="editdriver" class="editdriver" id="editdriver" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabeledit"><?php echo e(trans('labels.edit_driver')); ?></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <span id="emsg"></span>
                        <div class="modal-body">
                            <input type="hidden" class="form-control" id="id" name="id">
                            <input type="hidden" class="form-control" id="old_img" name="old_img">
                            <div class="form-group">
                                <label for="driver_id" class="col-form-label"><?php echo e(trans('labels.name')); ?></label>
                                <input type="text" class="form-control" id="get_name" name="name" placeholder="<?php echo e(trans('messages.enter_name')); ?>">
                            </div>
                            <div class="form-group">
                                <label for="get_email" class="col-form-label"><?php echo e(trans('labels.email')); ?></label>
                                <input type="text" class="form-control" name="email" id="get_email" placeholder="<?php echo e(trans('messages.enter_email')); ?>">
                            </div>
                            <div class="form-group">
                                <label for="get_mobile" class="col-form-label"><?php echo e(trans('labels.mobile')); ?></label>
                                <input type="text" class="form-control" name="mobile" id="get_mobile" placeholder="<?php echo e(trans('messages.enter_mobile')); ?>">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(trans('labels.close')); ?></button>
                            <?php if(env('Environment') == 'sendbox'): ?>
                                <button type="button" class="btn btn-primary" onclick="myFunction()"><?php echo e(trans('labels.update')); ?></button>
                            <?php else: ?>
                                <button type="submit" class="btn btn-primary"><?php echo e(trans('labels.update')); ?></button>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- row -->

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <span id="message"></span>
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title"><?php echo e(trans('labels.all_driver')); ?></h4>
                    <div class="table-responsive" id="table-display">
                        <?php echo $__env->make('theme.drivertable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- #/ container -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script type="text/javascript">
    $('.table').dataTable({
      aaSorting: [[0, 'DESC']]
    });
$(document).ready(function() {
     "use strict";
    $('#add_driver').on('submit', function(event){
        event.preventDefault();
        var form_data = new FormData(this);
        $('#preloader').show();
        $.ajax({
            url:"<?php echo e(URL::to('admin/driver/store')); ?>",
            method:"POST",
            data:form_data,
            cache: false,
            contentType: false,
            processData: false,
            dataType: "json",
            success: function(result) {
                $('#preloader').hide();
                var msg = '';
                if(result.error.length > 0)
                {
                    for(var count = 0; count < result.error.length; count++)
                    {
                        msg += '<div class="alert alert-danger">'+result.error[count]+'</div>';
                    }
                    $('#msg').html(msg);
                    setTimeout(function(){
                      $('#msg').html('');
                    }, 5000);
                }
                else
                {
                    msg += '<div class="alert alert-success mt-1">'+result.success+'</div>';
                    DriverTable();
                    $('#message').html(msg);
                    $("#addDriver").modal('hide');
                    $("#add_driver")[0].reset();
                    setTimeout(function(){
                      $('#message').html('');
                    }, 5000);
                }
            },
        })
    });

    $('#editdriver').on('submit', function(event){
        event.preventDefault();
        var form_data = new FormData(this);
        $('#preloader').show();
        $.ajax({
            url:"<?php echo e(URL::to('admin/driver/update')); ?>",
            method:'POST',
            data:form_data,
            cache: false,
            contentType: false,
            processData: false,
            dataType: "json",
            success: function(result) {
                $('#preloader').hide();
                var msg = '';
                if(result.error.length > 0)
                {
                    for(var count = 0; count < result.error.length; count++)
                    {
                        msg += '<div class="alert alert-danger">'+result.error[count]+'</div>';
                    }
                    $('#emsg').html(msg);
                    setTimeout(function(){
                      $('#emsg').html('');
                    }, 5000);
                }
                else
                {
                    msg += '<div class="alert alert-success mt-1">'+result.success+'</div>';
                    DriverTable();
                    $('#message').html(msg);
                    $("#EditDriver").modal('hide');
                    $("#editdriver")[0].reset();
                    setTimeout(function(){
                      $('#message').html('');
                    }, 5000);
                }
            },
        });
    });
});
function GetData(id) {
    $('#preloader').show();
    $.ajax({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url:"<?php echo e(URL::to('admin/driver/show')); ?>",
        data: {
            id: id
        },
        method: 'POST', //Post method,
        dataType: 'json',
        success: function(response) {
            $('#preloader').hide();
            jQuery("#EditDriver").modal('show');
            $('#id').val(response.ResponseData.id);
            $('#get_name').val(response.ResponseData.name);
            $('#get_email').val(response.ResponseData.email);
            $('#get_mobile').val(response.ResponseData.mobile);

            $('.gallerys').html("<img src="+response.ResponseData.image+" class='img-fluid' style='max-height: 200px;'>");
            $('#old_img').val(response.ResponseData.image);
        },
        error: function(error) {
            $('#preloader').hide();
        }
    })
}
function StatusUpdate(id,status) {
    swal({
        title: "<?php echo e(trans('messages.are_you_sure')); ?>",
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: "<?php echo e(trans('messages.yes')); ?>",
        cancelButtonText: "<?php echo e(trans('messages.no')); ?>",
        closeOnConfirm: false,
        closeOnCancel: false,
        showLoaderOnConfirm: true,
    },
    function(isConfirm) {
        if (isConfirm) {
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url:"<?php echo e(URL::to('admin/driver/status')); ?>",
                data: {
                    id: id,
                    status: status
                },
                method: 'POST', //Post method,
                dataType: 'json',
                success: function(response) {
                    if (response == 1) {
                        swal.close();
                        DriverTable();
                    } else {
                        swal("Cancelled", "<?php echo e(trans('messages.wrong')); ?> :(", "error");
                    }
                },
                error: function(e) {
                    swal("Cancelled", "<?php echo e(trans('messages.wrong')); ?> :(", "error");
                }
            });
        } else {
            swal("Cancelled", "<?php echo e(trans('messages.record_safe')); ?> :)", "error");
        }
    });
}
function DriverTable() {
    $('#preloader').show();
    $.ajax({
        url:"<?php echo e(URL::to('admin/driver/list')); ?>",
        method:'get',
        success:function(data){
            $('#preloader').hide();
            $('#table-display').html(data);
            $(".zero-configuration").DataTable()
        }
    });
}

$('#mobile').on('input', function (event) { 
    this.value = this.value.replace(/[^0-9]/g, '');
});

$('#get_mobile').on('input', function (event) { 
    this.value = this.value.replace(/[^0-9]/g, '');
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/driver.blade.php ENDPATH**/ ?>