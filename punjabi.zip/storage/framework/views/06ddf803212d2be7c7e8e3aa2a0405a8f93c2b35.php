<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>#</th>
            <th><?php echo e(trans('labels.profile_image')); ?></th>
            <th><?php echo e(trans('labels.name')); ?></th>
            <th><?php echo e(trans('labels.email')); ?></th>
            <th><?php echo e(trans('labels.mobile')); ?></th>
            <th><?php echo e(trans('labels.login_with')); ?></th>
            <th><?php echo e(trans('labels.otp_status')); ?></th>
            <th><?php echo e(trans('labels.created_at')); ?></th>
            <th><?php echo e(trans('labels.action')); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($getusers as $users) {
        ?>
        <tr id="dataid<?php echo e($users->id); ?>">
            <td><?php echo e($users->id); ?></td>
            <td><img src='<?php echo asset("storage/app/public/images/profile/".$users->profile_image); ?>' style="width: 100px;"></td>
            <td><?php echo e($users->name); ?></td>
            <td><?php echo e($users->email); ?></td>
            <td><?php echo e($users->mobile); ?></td>
            <td>
                <?php if($users->login_type == "facebook"): ?>
                    Facebook
                <?php elseif($users->login_type == "google"): ?>
                    Google
                <?php else: ?>
                    Normal
                <?php endif; ?>
            </td>
            <td>
                <?php if($users->is_verified == "1"): ?>
                    <?php echo e(trans('labels.verified')); ?>

                <?php else: ?>
                    <?php echo e(trans('labels.unverified')); ?>

                <?php endif; ?>
            </td>
            <td><?php echo e($users->created_at); ?></td>
            <td>
                <?php if(env('Environment') == 'sendbox'): ?>
                    <a href="#" data-toggle="tooltip" data-placement="top" onclick="myFunction()" title="" data-original-title="<?php echo e(trans('labels.block')); ?>">
                        <span class="badge badge-danger"><?php echo e(trans('labels.block')); ?></span>
                    </a>
                <?php else: ?>
                    <?php if($users->is_available == '1'): ?>
                        <a class="badge badge-danger px-2" onclick="StatusUpdate('<?php echo e($users->id); ?>','2')" style="color: #fff;"><?php echo e(trans('labels.block')); ?></a>
                    <?php else: ?>
                        <a class="badge badge-primary px-2" onclick="StatusUpdate('<?php echo e($users->id); ?>','1')" style="color: #fff;"><?php echo e(trans('labels.unblock')); ?></a>
                    <?php endif; ?>
                <?php endif; ?>

                <a data-toggle="tooltip" href="<?php echo e(URL::to('admin/user-details/'.$users->id)); ?>" data-original-title="<?php echo e(trans('labels.view')); ?>">
                    <span class="badge badge-warning"><?php echo e(trans('labels.view')); ?></span>
                </a>
            </td>
        </tr>
        <?php
        }
        ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/theme/userstable.blade.php ENDPATH**/ ?>