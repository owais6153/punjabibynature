<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>#</th>
            <th><?php echo e(trans('labels.image')); ?></th>
            <th><?php echo e(trans('labels.category')); ?></th>
            <th><?php echo e(trans('labels.created_at')); ?></th>
            <th><?php echo e(trans('labels.status')); ?></th>
            <th><?php echo e(trans('labels.action')); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($getcategory as $category) {
        ?>
        <tr id="dataid<?php echo e($category->id); ?>">
            <td><?php echo e($category->id); ?></td>
            <td><img src='<?php echo asset("storage/app/public/images/category/".$category->image); ?>' class='img-fluid' style='max-height: 50px;'></td>
            <td><?php echo e($category->category_name); ?></td>
            <td><?php echo e($category->created_at); ?></td>
            <?php if(env('Environment') == 'sendbox'): ?>
                <td>
                    <?php if($category->is_available == 1): ?>
                        <a class="badge badge-success px-2" onclick="myFunction()" style="color: #fff;"><?php echo e(trans('labels.active')); ?></a>
                    <?php else: ?>
                        <a class="badge badge-danger px-2" onclick="myFunction()" style="color: #fff;"><?php echo e(trans('labels.deactive')); ?></a>
                    <?php endif; ?>
                </td>
                <td>
                    <span>
                        <a href="#" data-toggle="tooltip" data-placement="top" onclick="GetData('<?php echo e($category->id); ?>')" title="" data-original-title="<?php echo e(trans('labels.edit')); ?>">
                            <span class="badge badge-success"><?php echo e(trans('labels.edit')); ?></span>
                        </a>

                        <a class="badge badge-danger px-2" onclick="myFunction()" style="color: #fff;"><?php echo e(trans('labels.delete')); ?></a>
                    </span>
                </td>
            <?php else: ?>
                <td>
                    <?php if($category->is_available == 1): ?>
                        <a class="badge badge-success px-2" onclick="StatusUpdate('<?php echo e($category->id); ?>','2')" style="color: #fff;"><?php echo e(trans('labels.active')); ?></a>
                    <?php else: ?>
                        <a class="badge badge-danger px-2" onclick="StatusUpdate('<?php echo e($category->id); ?>','1')" style="color: #fff;"><?php echo e(trans('labels.deactive')); ?></a>
                    <?php endif; ?>
                </td>
                <td>
                    <span>
                        <a href="#" data-toggle="tooltip" data-placement="top" onclick="GetData('<?php echo e($category->id); ?>')" title="" data-original-title="<?php echo e(trans('labels.edit')); ?>">
                            <span class="badge badge-success"><?php echo e(trans('labels.edit')); ?></span>
                        </a>

                        <a class="badge badge-danger px-2" onclick="Delete('<?php echo e($category->id); ?>')" style="color: #fff;"><?php echo e(trans('labels.delete')); ?></a>
                    </span>
                </td>
            <?php endif; ?>
        </tr>
        <?php
        }
        ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/theme/categorytable.blade.php ENDPATH**/ ?>