<!DOCTYPE html>
<html>

<head>
	<title><?php echo e($getabout->title); ?></title>

	<!-- meta tag -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="csrf-token" id="csrf-token" content="<?php echo e(csrf_token()); ?>">

	<meta property="og:title" content="<?php echo e($getabout->og_title); ?>" />
	<meta property="og:description" content="<?php echo e($getabout->og_description); ?>" />
	<meta property="og:image" content='<?php echo asset("storage/app/public/images/about/".$getabout->og_image); ?>' />

	<!----style css---->
	<link rel="stylesheet" type="text/css" href="<?php echo asset('storage/app/public/assets/css/custom-style.css'); ?>">
	<!-- favicon-icon  -->
	<link rel="icon" href='<?php echo asset("storage/app/public/images/about/".$getabout->favicon); ?>' type="image/x-icon">

	<!-- font-awsome css  -->
	<link rel="stylesheet" type="text/css" href="<?php echo asset('storage/app/public/front/css/font-awsome.css'); ?>">

	<!-- fonts css -->
	<link rel="stylesheet" type="text/css" href="<?php echo asset('storage/app/public/front/fonts/fonts.css'); ?>">

	<!-- bootstrap css -->
	<link rel="stylesheet" type="text/css" href="<?php echo asset('storage/app/public/front/css/bootstrap.min.css'); ?>">

	<!-- fancybox css -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />

	<!-- owl.carousel css -->
	<link rel="stylesheet" type="text/css" href="<?php echo asset('storage/app/public/front/css/owl.carousel.min.css'); ?>">

	<link href="<?php echo asset('storage/app/public/assets/plugins/sweetalert/css/sweetalert.css'); ?>" rel="stylesheet">
	<!-- style css  -->
	<link rel="stylesheet" type="text/css" href="<?php echo asset('storage/app/public/front/css/style.css'); ?>">

	<!-- responsive css  -->
	<link rel="stylesheet" type="text/css" href="<?php echo asset('storage/app/public/front/css/responsive.css'); ?>">
</head>

<body>

	<!--*******************
	    Preloader start
	********************-->
	<div id="preloader" style="display: none;">
	    <div class="loader">
	        <img src="<?php echo asset('storage/app/public/front/images/loader.gif'); ?>">
	    </div>
	</div>
	<!--*******************
	    Preloader end
	********************-->

	<!-- navbar -->
	<header>
		<nav class="navbar navbar-expand-lg nav-bar-top">
			<div class="container">
				<a class="navbar-brand" href="<?php echo e(URL::to('/')); ?>"><img src='<?php echo asset("storage/app/public/assets/images/logo-main.png"); ?>' alt=""></a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
					<div class="menu-icon">
						<div class="bar1"></div>
						<div class="bar2"></div>
						<div class="bar3"></div>
					</div>
				</button>
				<div class="collapse navbar-collapse" id="navbarNav">
					  
					<ul class="navbar-nav">
						<!-- <li><a href="<?php echo e(url('locale/en')); ?>" ><i class="fa fa-language"></i> EN</a></li>

						<li><a href="<?php echo e(url('locale/vi')); ?>" ><i class="fa fa-language"></i> VI</a></li> -->

						<?php if(Session::get('id')): ?>
						
							<li class="nav-item <?php echo e(request()->is('orders') ? 'active' : ''); ?>">
								<a class="nav-link" href="<?php echo e(URL::to('/orders')); ?>"><?php echo e(trans('labels.my_orders')); ?></a>
							</li>
							<li class="nav-item <?php echo e(request()->is('favorite') ? 'active' : ''); ?>">
								<a class="nav-link" href="<?php echo e(URL::to('/favorite')); ?>"><?php echo e(trans('labels.favourite_list')); ?></a>
							</li>
							<li class="nav-item <?php echo e(request()->is('wallet') ? 'active' : ''); ?>">
								<a class="nav-link" href="<?php echo e(URL::to('/wallet')); ?>"><?php echo e(trans('labels.my_wallet')); ?></a>
							</li>
							<li class="nav-item search">
								<form method="get" action="<?php echo e(URL::to('/search')); ?>">
									<div class="search-input">
										<input type="search" id="search-box" name="item" placeholder="<?php echo e(trans('messages.search_here')); ?>" required="" autocomplete="off">
									</div>
									<button type="submit" class="nav-link"><i class="far fa-search"></i></button>
								</form>
								<div id="countryList" class="item-list"></div>
							</li>
							<li class="nav-item cart-btn">
								<a class="nav-link" href="<?php echo e(URL::to('/cart')); ?>"><i class="fas fa-shopping-cart"></i><span id="cartcnt"><?php echo e(Session::get('cart')); ?></span></a>
							</li>
						<?php else: ?> 
							<li class="nav-item search">
								<form method="get" action="<?php echo e(URL::to('/search')); ?>">
									<div class="search-input">
										<input type="search" id="search-box" name="item" placeholder="<?php echo e(trans('messages.search_here')); ?>" required="" autocomplete="off">
									</div>
									<button type="submit" class="nav-link"><i class="far fa-search"></i></button>
								</form>
								<div id="countryList" class="item-list"></div>
							</li>
							<li class="nav-item cart-btn">
								<a class="nav-link" href="<?php echo e(URL::to('/signin')); ?>"><i class="fas fa-shopping-cart"></i></a>
							</li>
						<?php endif; ?>
						<?php if(Session::get('id')): ?>
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="javascript:void(0)">
									<img src='<?php echo asset("storage/app/public/images/profile/".Session::get("profile_image")); ?>' alt="">
								</a>
								<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
									<a class="dropdown-item" href="" data-toggle="modal" data-target="#EditProfile"><?php echo e(trans('labels.hello')); ?>, <?php echo e(Session::get('name')); ?></a>
									<a class="dropdown-item" href="<?php echo e(URL::to('/address')); ?>"><?php echo e(trans('labels.my_address')); ?></a>
									<a class="dropdown-item" href="" data-toggle="modal" data-target="#AddReview"><?php echo e(trans('labels.add_review')); ?></a>
									<a class="dropdown-item" href="" data-toggle="modal" data-target="#Refer"><?php echo e(trans('labels.refer_earn')); ?></a>
									<?php if(Session::get('login_type') == "email"): ?>
									<a class="dropdown-item" href="" data-toggle="modal" data-target="#ChangePasswordModal"><?php echo e(trans('labels.change_password')); ?></a>
									<?php endif; ?>
									<a class="dropdown-item" href="<?php echo e(URL::to('/logout')); ?>"><?php echo e(trans('labels.logout')); ?></a>
								</div>
							</li>
						<?php else: ?> 
							<li class="nav-item">
								<a class="nav-link btn sign-btn" href="<?php echo e(URL::to('/signin')); ?>">
									<i class="far fa-user"></i>
								<?php echo e(trans('labels.login')); ?></a>
							</li>
							<li class="nav-item">
								<a class="nav-link btn sign-btn" href="#">
									<i class="fas fa-phone-alt"></i>
									Call us</a>
							</li>
						<?php endif; ?>
						
					</ul>
				</div>
			
			</div>
		</nav>
		<nav class="navbar navbar-expand-lg nav-bottom-bar">
		<div class="container">
		
				<div class="collapse navbar-collapse" id="navbarNav">
							  
							<ul class="navbar-nav">
								<!-- <li class="nav-item <?php echo e(request()->is('/') ? 'active' : ''); ?>">
									<a class="nav-link" href="<?php echo e(URL::to('/')); ?>"><?php echo e(trans('labels.home')); ?></a>
								</li> -->
								<li class="nav-item <?php echo e(request()->is('product') ? 'active' : ''); ?>">
									<a class="nav-link" href="<?php echo e(URL::to('/product')); ?>">
										<i class="fas fa-bars"></i>
									Our Menu</a>
								</li>
								<li class="nav-item <?php echo e(request()->is('catering') ? 'active' : ''); ?>">
									<a class="nav-link" href="<?php echo e(URL::to('/catering')); ?>">
										<i class="fas fa-home"></i>
									Catering</a>
								</li>
								<li class="nav-item <?php echo e(request()->is('about') ? 'active' : ''); ?>">
									<a class="nav-link" href="<?php echo e(URL::to('/about')); ?>">
										<i class="fas fa-utensils"></i>
									About Us</a>
								</li>
								<li class="nav-item <?php echo e(request()->is('contact') ? 'active' : ''); ?>">
									<a class="nav-link" href="<?php echo e(URL::to('/contact')); ?>">
										<i class="fas fa-mobile"></i> 
									Contact</a>
								</li>
							
									
								
								
							</ul>
						</div>
		
	</div>
	</nav>
	</header>
	<!-- navbar -->
	<div id="success-msg" class="alert alert-dismissible mt-3" style="display: none;">
	    <span id="msg"></span>
	</div>

	<div id="error-msg" class="alert alert-dismissible mt-3" style="display: none;">
	    <span id="ermsg"></span>
	</div>

	<?php echo $__env->make('cookieConsent::index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\punjabi\resources\views/front/theme/header.blade.php ENDPATH**/ ?>