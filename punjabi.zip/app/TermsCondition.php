<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TermsCondition extends Model
{
    protected $table='terms';
    protected $fillable=['termscondition_content'];
}
